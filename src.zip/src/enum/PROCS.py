from enum import Enum, unique
@unique
class PROCS(Enum):
        ALL_PROCS = -7
        CAT_DATE = 0
        ADD_BB = 1
        ADD_PRV_VAL = 2
        ADD_PRC_STUD = 3
        ADD_VOL_STUD = 4
        ADD_AVG_STUD = 5
        ADD_MOM_STUD = 6
        ADD_CYC_STUD = 7
        ADD_CHART_PATTERN = 8